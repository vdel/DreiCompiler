let is_eof = function
  | None -> true
  | Some(_) -> false

let is_char c = function
  | None -> false
  | Some(c') -> c == c'

let is_not f c = not (f c)

let ( ||| ) f f' c = (f c) || (f' c)

let is_digit = function
  | None -> false
  | Some(c) -> (match c with '0'..'9' -> true | _ -> false)

let is_letter = function
  | None -> false
  | Some(c) -> (match c with 'a'..'z' | 'A'..'Z' -> true | _ -> false)

let is_whitespace = (is_char ' ') ||| (is_char '\t') ||| (is_char '\012') ||| (is_char '\n')

let string_such_that chars p =
  let buf = Buffer.create 10 in
    while(p (CharReader.current_char chars)) do
      let Some(c) = CharReader.current_char chars in
	CharReader.next_char chars;
	Buffer.add_char buf c
    done;
    Buffer.contents buf

type t = { chars: CharReader.t; mutable token: Tokens.token; mutable start: int * int }

let current_token o = o.token

let rec read_token o = 
  let accept_token tok = 
    CharReader.next_char o.chars;
    tok
  in
    if is_whitespace (CharReader.current_char o.chars) then 
      begin
	CharReader.next_char o.chars;
	read_token o
      end
    else
      begin
	o.start <- CharReader.get_position o.chars;
	match CharReader.current_char o.chars with
	    None -> Tokens.EOF
	  | Some('/') ->
	      begin
		CharReader.next_char o.chars;
		match CharReader.current_char o.chars with
		  | Some('/') ->
		      while
			CharReader.current_char o.chars <> Some('\n') 
			&& CharReader.current_char o.chars <> None 
		      do
			CharReader.next_char o.chars
		      done;
		      read_token o
		  | _ -> Tokens.DIV
	      end
	  | Some('-') -> accept_token Tokens.SUB
	  | Some('+') -> accept_token Tokens.ADD
	  | Some('*') -> accept_token Tokens.MUL
	  | Some('%') -> accept_token Tokens.MOD
	  | Some('(') -> accept_token Tokens.LPAREN
	  | Some(')') -> accept_token Tokens.RPAREN
	  | Some('{') -> accept_token Tokens.LBRACE
	  | Some('}') -> accept_token Tokens.RBRACE
	  | Some('.') -> accept_token Tokens.DOT
	  | Some(',') -> accept_token Tokens.COMMA
	  | Some(':') -> accept_token Tokens.COLON
	  | Some(';') -> accept_token Tokens.SEMICOLON
	  | Some('=') -> 
	      begin
		CharReader.next_char o.chars;
		match CharReader.current_char o.chars with
		  | Some('=') -> accept_token Tokens.EQ
		  | _ -> Tokens.EQUAL
	      end
	  | Some('<') -> 
	      begin
		CharReader.next_char o.chars;
		match CharReader.current_char o.chars with
		  | Some('=') -> accept_token Tokens.LE
		  | _ -> Tokens.LT
	      end
	  | Some('>') -> 
	      begin
		CharReader.next_char o.chars;
		match CharReader.current_char o.chars with
		  | Some('=') -> accept_token Tokens.GE
		  | _ -> Tokens.GT
	      end
	  | Some('&') ->
	      begin
		CharReader.next_char o.chars;
		match CharReader.current_char o.chars with
		  | Some('&') -> accept_token Tokens.AND
		  | _ -> 
		      Report.fail_at_pos o.start "Use && instead of &";
		      Tokens.BAD('&')
	      end
	  | Some('|') ->
	      begin
		CharReader.next_char o.chars;
		match CharReader.current_char o.chars with
		  | Some('|') -> accept_token Tokens.OR
		  | _ -> 
		      Report.fail_at_pos o.start "Use || instead of |";
		      Tokens.BAD('|')
	      end
	  | Some('!') -> 
	      begin
		CharReader.next_char o.chars;
		match CharReader.current_char o.chars with
		  | Some('=') -> accept_token Tokens.NE
		  | _ -> Tokens.NOT
	      end
	  | Some('"') ->
	      CharReader.next_char o.chars;
              let is_premature_end = is_eof ||| (is_char '\n') in
              let string = string_such_that o.chars (is_not ((is_char '"') ||| is_premature_end)) in
                if is_premature_end (CharReader.current_char o.chars) then
                  Report.fail_at_pos o.start "unterminated string"
                else accept_token (Tokens.STRING(string))
	  | c when is_letter(c) ->
	      let string = string_such_that o.chars (is_letter ||| is_digit ||| (is_char '_')) in
		Tokens.token_of_keyword string
	  | c when is_char '0' c -> accept_token (Tokens.NUMBER(Int32.zero))
	  | c when is_digit c ->
	      let string = string_such_that o.chars is_digit in
		begin
		  try
		    Tokens.NUMBER(Int32.of_string string)
		  with Failure(_) -> 
		    Report.fail_at_pos o.start ("Integer too big: "^string);
		    Tokens.NUMBER(Int32.zero)
		end
	  | Some(c) -> 
              Report.fail_at_pos o.start ("bad character of code "^(string_of_int (Char.code c)));
	      accept_token (Tokens.BAD(c))
      end

let next_token o = o.token <- read_token o

let get_position o = o.start

let new_scanner chars = 
  let o = { chars = chars; 
	    token = Tokens.EOF;
	    start = (0,0) }
  in 
    next_token o;
    o

let main filename =
  let in_channel = if filename = "--" then stdin else open_in filename in
  let chars = CharReader.charReader_of_in_channel in_channel in
  let scanner = new_scanner chars in
    while current_token scanner <> Tokens.EOF do
      print_string (Tokens.string_of_token (current_token scanner));
      print_newline();
      next_token scanner
    done
