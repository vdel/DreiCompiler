let main () =
  Arg.parse ["-scanner",Arg.String(Scanner.main),"test the scanner phase on the given file";
 	     "-parser",Arg.String(Parser.main),"test the parser phase on the given file"; 
	    ]
    (fun str -> prerr_string "Ignored argument: ";prerr_string str;prerr_newline())
    "drei compiler - L3IF 2007 - ENS Lyon"

let _ = main ()
