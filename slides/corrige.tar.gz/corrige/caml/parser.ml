open Tokens

let accept_token scanner t =
  let t' = Scanner.current_token scanner in
    if t = t' then Scanner.next_token scanner
    else Report.fail_at_pos (Scanner.get_position scanner) ("expected token: "^(string_of_token t)^" but found:"^(string_of_token t'))

let check_token scanner t =
  let t' = Scanner.current_token scanner in
    if t = t' then (Scanner.next_token scanner; true)
    else false

let parse_ident scanner =
  match Scanner.current_token scanner with
    | IDENT(s) -> Scanner.next_token scanner
    | t -> Report.fail_at_pos (Scanner.get_position scanner) ("expected an identifier but found:"^(string_of_token t))

let parse_number scanner =
  match Scanner.current_token scanner with
    | NUMBER(n) -> Scanner.next_token scanner
    | t -> Report.fail_at_pos (Scanner.get_position scanner) ("expected a number but found:"^(string_of_token t))

let parse_type scanner =
  if check_token scanner INT then ()
  else parse_ident scanner

let parse_formal scanner =
  parse_ident scanner;
  accept_token scanner COLON;
  parse_type scanner

let rec parse_formals scanner = 
  let rec aux () = 
    if check_token scanner COMMA then 
      begin
	parse_formal scanner;
	aux ()
      end
  in
    match Scanner.current_token scanner with
      | IDENT(_) -> parse_formal scanner; aux ()
      | _ -> ()

let parse_comp_op scanner =
  if check_token scanner EQ then ()
  else if check_token scanner NE then ()
  else if check_token scanner LT then ()
  else if check_token scanner LE then ()
  else if check_token scanner GT then ()
  else accept_token scanner GE

let rec parse_program scanner =
  let rec aux () =
    if Scanner.current_token scanner = CLASS then
      begin
	parse_class scanner;
	aux ()
      end
  in
    aux ();
    parse_statement scanner
and parse_class scanner =
  accept_token scanner CLASS;
  parse_ident scanner;
  if check_token scanner EXTENDS then parse_ident scanner;
  accept_token scanner LBRACE;
  parse_members scanner;
  accept_token scanner RBRACE
and parse_members scanner =
  let rec aux () =
    match Scanner.current_token scanner with
      | VAL | DEF -> 
	  parse_member scanner;
	  aux ()
      | _ -> ()
  in aux ()
and parse_member scanner = 
  if check_token scanner VAL then
    begin
      parse_formal scanner;
      accept_token scanner SEMICOLON
    end
  else
    begin
      accept_token scanner DEF;
      parse_ident scanner;
      accept_token scanner LPAREN;
      parse_formals scanner;
      accept_token scanner RPAREN;
      if check_token scanner LBRACE then
	begin
	  parse_statements scanner;
	  accept_token scanner RBRACE
	end
      else
	begin
	  accept_token scanner COLON;
	  parse_type scanner;
	  accept_token scanner EQUAL;
	  parse_expression scanner;
	  accept_token scanner SEMICOLON
	end
    end
and parse_vardecl scanner = 
  accept_token scanner VAR;
  parse_formal scanner;
  accept_token scanner EQUAL;
  parse_expression scanner;
  accept_token scanner SEMICOLON
and parse_statement scanner =
  match Scanner.current_token scanner with
    | WHILE ->
	Scanner.next_token scanner;
	accept_token scanner LPAREN;
	parse_expression scanner;
	accept_token scanner RPAREN;
	parse_statement scanner
    | IF ->
	Scanner.next_token scanner;
	accept_token scanner LPAREN;
	parse_expression scanner;
	accept_token scanner RPAREN;
	parse_statement scanner;
	if check_token scanner ELSE then parse_statement scanner
    | SET ->
	Scanner.next_token scanner;
	parse_ident scanner;
	accept_token scanner EQUAL;
	parse_expression scanner;
	accept_token scanner SEMICOLON
    | DO ->
	Scanner.next_token scanner;
	parse_expression scanner;
	accept_token scanner SEMICOLON
    | PRINTINT ->
	Scanner.next_token scanner;
	accept_token scanner LPAREN;
	parse_expression scanner;
	accept_token scanner RPAREN;
	accept_token scanner SEMICOLON
    | PRINTCHAR ->
	Scanner.next_token scanner;
	accept_token scanner LPAREN;
	parse_expression scanner;
	accept_token scanner RPAREN;
	accept_token scanner SEMICOLON
    | _ ->
	accept_token scanner LBRACE;
	parse_statements scanner;
	accept_token scanner RBRACE
and parse_statements scanner = 
  let rec aux () = 
    match Scanner.current_token scanner with
      | WHILE | IF | SET | DO | PRINTINT | PRINTCHAR | LBRACE -> 
	  parse_statement scanner;aux()
      | VAR -> 
	  parse_vardecl scanner;aux ()
      | _ -> ()
  in aux ()
and parse_expression scanner = 
  parse_sum_expression scanner;
  match Scanner.current_token scanner with
    | EQ | NE | LT | LE | GT | GE ->
	parse_comp_op scanner;
	parse_sum_expression scanner
    | _ -> ()
and parse_sum_expression scanner =
  let rec aux () =
    if check_token scanner ADD then 
      begin
	parse_term scanner;
	aux ()
      end
    else if check_token scanner SUB then 
      begin
	parse_term scanner;
	aux ()
      end
    else if check_token scanner OR then 
      begin
	parse_term scanner;
	aux ()
      end
  in 
    parse_term scanner;
    aux ()
and parse_term scanner = 
  let rec aux () =
    if check_token scanner MUL then 
      begin
	parse_signedfactor scanner;
	aux ()
      end
    else if check_token scanner DIV then 
      begin
	parse_signedfactor scanner;
	aux ()
      end
    else if check_token scanner MOD then 
      begin
	parse_signedfactor scanner;
	aux ()
      end
    else if check_token scanner AND then 
      begin
	parse_signedfactor scanner;
	aux ()
      end
  in 
    parse_signedfactor scanner;
    aux ()
and parse_signedfactor scanner = 
  if check_token scanner NOT then parse_factor scanner
  else if check_token scanner SUB then parse_factor scanner
  else parse_factor scanner
and parse_factor scanner = 
  let rec aux () =
    if check_token scanner DOT then
      begin
	parse_ident scanner;
	if Scanner.current_token scanner = LPAREN then 
	  begin
	    parse_params scanner; 
	    aux ()
	  end
	  else aux ()
      end
  in 
    parse_simple_factor scanner;
    aux ()
and parse_simple_factor scanner =
  match Scanner.current_token scanner with
    | IDENT(_) -> Scanner.next_token scanner
    | THIS -> Scanner.next_token scanner
    | NUMBER(n) -> Scanner.next_token scanner
    | STRING(s) -> Scanner.next_token scanner
    | TRUE -> Scanner.next_token scanner
    | FALSE -> Scanner.next_token scanner
    | READINT -> Scanner.next_token scanner
    | READCHAR -> Scanner.next_token scanner
    | LPAREN ->
	Scanner.next_token scanner;
	parse_expression scanner;
	accept_token scanner RPAREN
    | LBRACE ->
	Scanner.next_token scanner;
	parse_statements scanner;
	accept_token scanner RETURN;
	parse_expression scanner;
	accept_token scanner RBRACE
    | _ -> 
	accept_token scanner NEW;
	parse_ident scanner;
	parse_params scanner
and parse_params scanner = 
  let rec aux () = 
    if check_token scanner COMMA then 
      begin
	parse_expression scanner;
	aux ()
      end
  in
    accept_token scanner LPAREN;
    if check_token scanner RPAREN then ()
    else 
      begin
	parse_expression scanner;
	aux ();
	accept_token scanner RPAREN
      end

let parse_program scanner = 
  parse_program scanner;
  accept_token scanner EOF

let main filename =
  let in_channel = if filename = "--" then stdin else open_in filename in
  let chars = CharReader.charReader_of_in_channel in_channel in
  let scanner = Scanner.new_scanner chars in
    ignore (parse_program scanner)


	
  
				 
