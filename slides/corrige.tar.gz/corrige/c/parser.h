#ifndef PARSER_H
#define PARSER_H

#include "scanner.h"

void parse_program(scanner *sc);

#endif
