#ifndef CHARREADER_H
#define CHARREADER_H

#include <stdio.h>

typedef struct {
  int cchar;
  int line;
  int column;
  FILE *instream;
} charReader;

void next_char(charReader *chars);
charReader *new_charReader(FILE *stream);
void delete_charReader(charReader *chars);

#endif
