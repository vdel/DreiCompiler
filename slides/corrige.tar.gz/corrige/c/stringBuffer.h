#ifndef STRINGBUFFER_H
#define STRINGBUFFER_H

typedef struct {
  int idx;
  int size;
  char *content;
} stringBuffer;

stringBuffer *new_stringBuffer(int size);
void delete_stringBuffer(stringBuffer *buf);
char *get_content(stringBuffer *sbuf);
void add_char(stringBuffer *sbuf, char c);

#endif
