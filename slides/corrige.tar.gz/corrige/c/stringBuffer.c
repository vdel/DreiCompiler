#include "stringBuffer.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>

stringBuffer *new_stringBuffer(int size) {
  if(size < 1) {
    size = 1;
  }
  char *buf = (char *)malloc(size*sizeof(char));
  stringBuffer *sbuf = malloc(sizeof(stringBuffer));

  assert(buf != NULL);
  assert(sbuf != NULL);

  buf[0] = 0;

  sbuf->idx = 0;
  sbuf->size=size;
  sbuf->content = buf;

  return sbuf;
}

void delete_stringBuffer(stringBuffer *sbuf) {
  assert(sbuf != NULL);
  assert(sbuf->content != NULL);
  free(sbuf->content);
  sbuf->content = NULL;
  free(sbuf);
}

char *get_content(stringBuffer *sbuf) {
  assert(sbuf != NULL);

  char *content = (char *)malloc((1+sbuf->idx)*sizeof(char));
  assert(content != NULL);

  memmove(content,sbuf->content,sbuf->idx*sizeof(char));
  content[sbuf->idx] = 0;

  return content;
}

void add_char(stringBuffer *sbuf, char c) {
  assert(sbuf != NULL);
  assert(sbuf->content != NULL);
  if(sbuf->idx == sbuf->size) {
    sbuf->size *= 2;
    sbuf->content = realloc(sbuf->content,sbuf->size*sizeof(char));
    assert(sbuf->content != NULL);
  }
  sbuf->content[sbuf->idx++] = c;
}
