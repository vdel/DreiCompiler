#include "scanner.h"
#include "report.h"
#include "token.h"

void accept_token(scanner *sc, int tok) {
  if(sc->token == tok) {
    next_token(sc);
  } else {
    error("%d,%d: expected %s but found %s\n",
	  sc->line,sc->column,
	  token_representation[tok],
	  token_representation[sc->token]);
  }
}

int check_token(scanner *sc, int tok) {
  if(sc->token == tok) {
    next_token(sc);
    return 1;
  } 
  return 0;
}

void parse_ident(scanner *sc);
void parse_type(scanner *sc);
void parse_formal(scanner *sc);
void parse_formals(scanner *sc);
void parse_comp_op(scanner *sc);
void parse_class(scanner *sc);
void parse_member(scanner *sc);
void parse_members(scanner *sc);
void parse_vardecl(scanner *sc);
void parse_statement(scanner *sc);
void parse_statements(scanner *sc);
void parse_expression(scanner *sc);
void parse_sum_expression(scanner *sc);
void parse_term(scanner *sc);
void parse_signed_factor(scanner *sc);
void parse_factor(scanner *sc);
void parse_simple_factor(scanner *sc);
void parse_params(scanner *sc);

void parse_ident(scanner *sc) {
  if(sc->token == IDENT) {
    next_token(sc);
  } else {
    error("%d,%d: expected an identifier but found %s\n",
	  sc->line,sc->column,
	  token_representation[sc->token]);
  }
}

void parse_type(scanner *sc) {
  if(check_token(sc,INT)) {
  } else {
    parse_ident(sc);
  }
}

void parse_formal(scanner *sc) {
  parse_ident(sc);
  accept_token(sc,COLON);
  parse_type(sc);
}

void parse_formals(scanner *sc) {
  if(sc->token == IDENT) {
    parse_formal(sc);
    while(sc->token == COMMA) {
      next_token(sc);
      parse_formal(sc);
    }
  }
}

void parse_comp_op(scanner *sc) {
  if(check_token(sc,EQ)) {
  } else if(check_token(sc,NE)) {
  } else if(check_token(sc,LT)) {
  } else if(check_token(sc,LE)) {
  } else if(check_token(sc,GT)) {
  } else {
    accept_token(sc,GE);
  }
}

void parse_class(scanner *sc) {
  accept_token(sc,CLASS);
  parse_ident(sc);
  if(check_token(sc,EXTENDS)) {
    parse_ident(sc);
  }
  accept_token(sc,LBRACE);
  parse_members(sc);
  accept_token(sc,RBRACE);
}

void parse_member(scanner *sc) {
  if(check_token(sc,VAL)) {
    parse_formal(sc);
    accept_token(sc,SEMICOLON);
  } else {
    accept_token(sc,DEF);
    parse_ident(sc);
    accept_token(sc,LPAREN);
    parse_formals(sc);
    accept_token(sc,RPAREN);
    if(check_token(sc,LBRACE)) {
      parse_statements(sc);
      accept_token(sc,RBRACE);
    } else {
      accept_token(sc,COLON);
      parse_type(sc);
      accept_token(sc,EQUAL);
      parse_expression(sc);
      accept_token(sc,SEMICOLON);
    }
  }
}

void parse_vardecl(scanner *sc) {
  accept_token(sc,VAR);
  parse_formal(sc);
  accept_token(sc,EQUAL);
  parse_expression(sc);
  accept_token(sc,SEMICOLON);
}

void parse_members(scanner *sc) {
  while((sc->token == VAL) || (sc->token == DEF)) {
    parse_member(sc);
  }
}

void parse_statement(scanner *sc) {
  switch(sc->token) {
  case WHILE:
    next_token(sc);
    accept_token(sc,LPAREN);
    parse_expression(sc);
    accept_token(sc,RPAREN);
    parse_statement(sc);
    break;
  case IF:
    next_token(sc);
    accept_token(sc,LPAREN);
    parse_expression(sc);
    accept_token(sc,RPAREN);
    parse_statement(sc);
    if(check_token(sc,ELSE)) {
      parse_statement(sc);
    }
    break;
  case SET:
    next_token(sc);
    parse_ident(sc);
    accept_token(sc,EQUAL);
    parse_expression(sc);
    accept_token(sc,SEMICOLON);
    break;
  case DO:
    next_token(sc);
    parse_expression(sc);
    accept_token(sc,SEMICOLON);
    break;
  case PRINTINT:
    next_token(sc);
    accept_token(sc,LPAREN);
    parse_expression(sc);
    accept_token(sc,RPAREN);
    accept_token(sc,SEMICOLON);
    break;
  case PRINTCHAR:
    next_token(sc);
    accept_token(sc,LPAREN);
    parse_expression(sc);
    accept_token(sc,RPAREN);
    accept_token(sc,SEMICOLON);
    break;
  default:
    accept_token(sc,LBRACE);
    parse_statements(sc);
    accept_token(sc,RBRACE);
  }
}

void parse_statements(scanner *sc) {
  while((sc->token == WHILE) ||
	(sc->token == IF) ||
	(sc->token == SET) || 
	(sc->token == DO) ||
	(sc->token == PRINTINT) ||
	(sc->token == PRINTCHAR) ||
	(sc->token == LBRACE) ||
	(sc->token == VAR)) {
    if(sc->token == VAR) {
      parse_vardecl(sc);
    } else {
      parse_statement(sc);
    }
  }
}

void parse_expression(scanner *sc) {
  parse_sum_expression(sc);
  if((sc->token == EQ) ||
     (sc->token == NE) ||
     (sc->token == LT) ||
     (sc->token == LE) ||
     (sc->token == GT) ||
     (sc->token == GE)) {
    parse_comp_op(sc);
    parse_sum_expression(sc);
  }
}

void parse_sum_expression(scanner *sc) {
  parse_term(sc);
  while((sc->token == ADD) ||
	(sc->token == SUB) ||
	(sc->token == OR)) {
    next_token(sc);
    parse_term(sc);
  }
}

void parse_term(scanner *sc) {
  parse_signed_factor(sc);
  while((sc->token == MUL) ||
	(sc->token == DIV) ||
	(sc->token == MOD) ||
	(sc->token == AND)) {
    next_token(sc);
    parse_signed_factor(sc);
  }
}

void parse_signed_factor(scanner *sc) {
  if(check_token(sc,NOT)) {
    parse_factor(sc);
  } else if(check_token(sc,SUB)) {
    parse_factor(sc);
  } else {
    parse_factor(sc);
  }
}

void parse_factor(scanner *sc) {
  parse_simple_factor(sc);
  while(sc->token == DOT) {
    next_token(sc);
    parse_ident(sc);
    if(sc->token == LPAREN) {
      parse_params(sc);
    }
  }
}

void parse_simple_factor(scanner *sc) {
  switch(sc->token) {
  case IDENT:
    next_token(sc);
    break;
  case THIS:
    next_token(sc);
    break;
  case NUMBER:
    next_token(sc);
    break;
  case STRING:
    next_token(sc);
    break;
  case TRUE:
    next_token(sc);
    break;
  case FALSE:
    next_token(sc);
    break;
  case READINT:
    next_token(sc);
    break;
  case READCHAR:
    next_token(sc);
    break;
  case LPAREN:
    next_token(sc);
    parse_expression(sc);
    accept_token(sc,RPAREN);
    break;
  case LBRACE:
    next_token(sc);
    parse_statements(sc);
    accept_token(sc,RETURN);
    parse_expression(sc);
    accept_token(sc,RBRACE);
    break;
  default:
    accept_token(sc,NEW);
    parse_ident(sc);
    parse_params(sc);
    break;
  }
}

void parse_params(scanner *sc) {
  accept_token(sc,LPAREN);
  if(check_token(sc,RPAREN)) {
  } else {
    parse_expression(sc);
    while(sc->token == COMMA) {
      next_token(sc);
      parse_expression(sc);
    }
    accept_token(sc,RPAREN);
  }
}

void parse_program(scanner *sc) {
  while(sc->token == CLASS) {
    parse_class(sc);
  }
  parse_statement(sc);
  accept_token(sc,EOFTOK);
}

