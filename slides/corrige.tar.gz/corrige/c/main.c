#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include "charReader.h"
#include "scanner.h"
#include "parser.h"

#define SCANNER 0
#define PARSER 1

void usage() {
  fprintf(stderr,"drei compiler - L3IF 2007 - ENS Lyon\n");
  fprintf(stderr,"-scanner test the scanner phase\n");
  fprintf(stderr,"-parser test the parser phase\n");
}

FILE *safe_open(char *fname) {
  FILE *fp = NULL;
  //  fprintf(stderr,"trying to open %s\n",fname);
  fp = fopen(fname,"r");
  if(fp == NULL) {
    fprintf(stderr,"%s\n",strerror(errno));
    exit(-1);
  }
  return fp;
}

int main(int argc, char *argv[]) {
  int i;
  FILE *fp = NULL;
  int phase = -1;
  for(i = 1; i < argc; i++) {
    if(strcmp("-scanner",argv[i]) == 0) {
      i++;
      fp = (i < argc) ? safe_open(argv[i]) : stdin;
      phase = SCANNER;
      break;
    } else if(strcmp("-parser",argv[i]) == 0) {
      i++;
      fp = (i < argc) ? safe_open(argv[i]) : stdin;
      phase = PARSER;
      break;
    }
  }
  if(fp == NULL) {
    usage();
    return 0;
  }
  charReader *chars = new_charReader(fp);
  scanner *sc = new_scanner(chars);
  switch(phase) {
  case SCANNER:
    while(sc->token != EOFTOK) {
      //     fprintf(stdout,"%d %d",tline,tcolumn);
      print_scanner_state(stdout,sc);
      fprintf(stdout,"\n");
      next_token(sc);
    }
    break;
  case PARSER:
    parse_program(sc);
    break;
  default:
    usage();
  }
  return 0;
}
