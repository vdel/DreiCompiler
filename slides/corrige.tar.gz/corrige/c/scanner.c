#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "token.h"
#include "charReader.h"
#include "report.h"
#include "stringBuffer.h"
#include "scanner.h"

char *token_representation[48] = {
  "BAD","EOF","IDENT","NUMBER","STRING",
  "(",")","{","}",".",
  ",",":",";","=","==",
  "!=","<","<=",">",">=",
  "!","&&","||","+","-",
  "*","/","%","Int","class",
  "extends","def","val","while","if",
  "else","var","set","do","false",
  "true","new","this","return","printInt",
  "printChar","readInt","readChar"
};

void print_scanner_state(FILE *fp,scanner *sc) {
  fprintf(fp,"%s",token_representation[sc->token]);
  switch(sc->token) {
  case IDENT:
    fprintf(fp,"(%s)",sc->str_value);
    break;
  case NUMBER:
    fprintf(fp,"(%d)",sc->int_value);
    break;
  case STRING:
    fprintf(fp,"(%s)",sc->str_value);
    break;
  }
}

int is_digit(int ch) {
  return (('0' <= ch) && (ch <= '9'));
}

int is_letter(int ch) {
  return ((('a' <= ch) && (ch <= 'z')) || (('A' <= ch) && (ch <= 'Z')));
}

void next_token(scanner *sc) {
  sc->line = sc->chars->line;
  sc->column = sc->chars->column;
  switch(sc->chars->cchar) {
  case EOF: 
    sc->token = EOFTOK;
    break;
  case ' ':
  case '\t':
  case '\n':
  case '\f':
    next_char(sc->chars);
    next_token(sc);
    break;
  case '/':
    next_char(sc->chars);
    if(sc->chars->cchar == '/') {
      while(sc->chars->cchar != '\n' && sc->chars->cchar != EOF) {
	next_char(sc->chars);
      }
      next_token(sc);
    } else {
      sc->token = DIV;
    }
    break;
  case '+':
    next_char(sc->chars);
    sc->token = ADD;
    break;
  case '-':
    next_char(sc->chars);
    sc->token = SUB;
    break;
  case '*':
    next_char(sc->chars);
    sc->token = MUL;
    break;
  case '%':
    next_char(sc->chars);
    sc->token = MOD;
    break;
  case '=':
    next_char(sc->chars);
    if(sc->chars->cchar == '=') {
      next_char(sc->chars);
      sc->token = EQ;
    } else {
      sc->token = EQUAL;
    }
    break;
  case '<':
    next_char(sc->chars);
    if(sc->chars->cchar == '=') {
      next_char(sc->chars);
      sc->token = LE;
    } else {
      sc->token = LT;
    }
    break;
  case '>':
    next_char(sc->chars);
    if(sc->chars->cchar == '=') {
      next_char(sc->chars);
      sc->token = GE;
    } else {
      sc->token = GT;
    }
    break;
  case '&':
    next_char(sc->chars);
    if(sc->chars->cchar == '&') {
      next_char(sc->chars);
      sc->token = AND;
    } else {
      error("%d,%d: %s\n",sc->line,sc->column,"use && instead of &");
    }
    break;
  case '|':
    next_char(sc->chars);
    if(sc->chars->cchar == '|') {
      next_char(sc->chars);
      sc->token = OR;
    } else {
      error("%d,%d: %s\n",sc->line,sc->column,"use || instead of |");
    }
    break;
  case '(':
    next_char(sc->chars);
    sc->token = LPAREN;
    break;
  case ')':
    next_char(sc->chars);
    sc->token = RPAREN;
    break;
  case '{':
    next_char(sc->chars);
    sc->token = LBRACE;
    break;
  case '}':
    next_char(sc->chars);
    sc->token = RBRACE;
    break;
  case '.':
    next_char(sc->chars);
    sc->token = DOT;
    break;
  case ',':
    next_char(sc->chars);
    sc->token = COMMA;
    break;
  case ':':
    next_char(sc->chars);
    sc->token = COLON;
    break;
  case ';':
    next_char(sc->chars);
    sc->token = SEMICOLON;
    break;
  case '!':

    next_char(sc->chars);
    if(sc->chars->cchar == '=') {
      next_char(sc->chars);
      sc->token = NE;
    } else {
      sc->token = NOT;
    }
    break;
  case '0':
    next_char(sc->chars);
    sc->int_value = 0;
    sc->token = NUMBER;
    break;
  default:
    if(is_digit(sc->chars->cchar)) {
      sc->int_value = 0;
      while(is_digit(sc->chars->cchar)) {
	sc->int_value *= 10;
	sc->int_value += (sc->chars->cchar - '0');
	next_char(sc->chars);
      }
      sc->token = NUMBER;
    } else if(is_letter(sc->chars->cchar)) {
      stringBuffer *buf = new_stringBuffer(1);
      while((is_letter(sc->chars->cchar)) || (is_digit(sc->chars->cchar)) || (sc->chars->cchar == '_')) {
	add_char(buf,(char)sc->chars->cchar);
	next_char(sc->chars);
      }
      char *ident = get_content(buf);
      sc->token = IDENT;
      sc->str_value = ident;
      int j;
      for(j = INT; j <= READCHAR; j++) {
	if(strcmp(ident,token_representation[j]) == 0) {
	  sc->token = j;
	  break;
	}
      }
      if(sc->token != IDENT) {
	sc->str_value = NULL;
	free(ident);
      }
      delete_stringBuffer(buf);
    } else if(sc->chars->cchar == '"') {
      next_char(sc->chars);
      stringBuffer *buf = new_stringBuffer(1);
      while((sc->chars->cchar != EOF) && (sc->chars->cchar != '\n') && (sc->chars->cchar != '"')) {
	add_char(buf,(char)sc->chars->cchar);
	next_char(sc->chars);
      }
      if(sc->chars->cchar == '"') {
	next_char(sc->chars);
	sc->str_value = get_content(buf);
	sc->token = STRING;
	delete_stringBuffer(buf);
      } else {
	error("%d,%d: %s\n",sc->line,sc->column,"unclosed string");
      }
    } else  {
      sc->int_value = sc->chars->cchar;
      next_char(sc->chars);
      sc->token = BADTOK;
      error("%d,%d: illegal character of code %d\n",sc->line,sc->column,sc->int_value);
    }
    break;
  }
}

scanner *new_scanner(charReader *chars) {
  assert(chars != NULL);
  scanner *res = (scanner *)malloc(sizeof(scanner));
  assert(res != NULL);
  res->chars = chars;
  res->token = BADTOK;
  res->int_value = -1;
  res->str_value = NULL;
  res->line = 0;
  res->column= 0;
  next_token(res);
  return res;
}

