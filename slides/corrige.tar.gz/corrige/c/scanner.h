#ifndef SCANNER_H
#define SCANNER_H

#include <stdio.h>
#include "token.h"
#include "charReader.h"

typedef struct {
  int token;
  char *str_value;
  int int_value;
  int line;
  int column;
  charReader *chars;
} scanner;

extern char *token_representation[48];

void print_scanner_state(FILE *fp,scanner *sc);
void next_token(scanner *sc);
scanner *new_scanner();

#endif
