#ifndef TOKEN_H
#define TOKEN_H

#define BADTOK 0
#define EOFTOK 1
#define IDENT 2
#define NUMBER 3
#define STRING 4
#define LPAREN 5
#define RPAREN 6
#define LBRACE 7
#define RBRACE 8
#define DOT 9
#define COMMA 10
#define COLON 11
#define SEMICOLON 12
#define EQUAL 13
#define EQ 14
#define NE 15
#define LT 16
#define LE 17
#define GT 18
#define GE 19
#define NOT 20
#define AND 21
#define OR 22
#define ADD 23
#define SUB 24
#define MUL 25
#define DIV 26
#define MOD 27
#define INT 28
#define CLASS 29
#define EXTENDS 30
#define DEF 31
#define VAL 32
#define WHILE 33
#define IF 34
#define ELSE 35
#define VAR 36
#define SET 37
#define DO 38
#define FALSE 39
#define TRUE 40
#define NEW 41
#define THIS 42
#define RETURN 43
#define PRINTINT 44
#define PRINTCHAR 45
#define READINT 46
#define READCHAR 47

#endif
