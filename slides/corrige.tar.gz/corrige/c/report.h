#ifndef REPORT_H
#define REPORT_H

#include <stdarg.h>

void error(const char *fmt, ...);

#endif
