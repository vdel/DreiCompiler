#include <stdlib.h>
#include <assert.h>
#include "charReader.h"

void next_char(charReader *chars) {
  if(chars->cchar == '\n') {
    chars->column = 0;
    chars->line++;
  } else {
    chars->column++;
  }
  if(chars->cchar != EOF) {
    chars->cchar = fgetc(chars->instream);
  }
}

charReader *new_charReader(FILE *stream) {
  assert(stream != NULL);
  charReader *res = (charReader *)malloc(sizeof(charReader));
  assert(res != NULL);
  res->instream = stream;
  res->column = -1;
  res->line = 0;
  next_char(res);
  return res;
}

void delete_charReader(charReader *chars) {
  assert(chars != NULL);
  fclose(chars->instream);
  chars->instream = NULL;
  free(chars);
}
